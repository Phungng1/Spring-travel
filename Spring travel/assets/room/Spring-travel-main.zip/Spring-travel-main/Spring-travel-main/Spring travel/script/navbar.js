let divNavbar = document.getElementById("nav")

divNavbar.innerHTML += `
<div class="navbar">

<div class="logo">
    <a href="../html/home.html" style="color: white;"><i class="fa-solid fa-umbrella-beach"> Oasis</i></a>
</div>
<div class="aspects">
    <div class="drop">
        <a href="../html/home.html" class="link">Home</a>
    </div>
    <div class="drop">
        <a href="../html/location.html" class="link">Hotel</a>
    </div>
    <div class="drop">
        <a href="../html/info.html" class="link">Room</a>
    </div>
    <div class="drop">
        <a href="../html/about us.html">About Us</a>
    </div>
    <div class="drop">
        <a href="../html/contact.html">Contact</a>
    </div>
</div>


</div>
`