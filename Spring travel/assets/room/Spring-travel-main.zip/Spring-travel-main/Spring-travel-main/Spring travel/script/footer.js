let divFooter = document.getElementById("footer")

divFooter.innerHTML += `
<footer>
        <div class="out">
            <i class="fa-solid fa-umbrella-beach"> Oasis</i>
            <div class="sm">
                <a href="https://www.facebook.com/" target="_blank"><i class="fa-brands fa-facebook"></i></a>
                <a href="https://www.instagram.com/" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                <a href="https://www.tiktok.com/foryou" target="_blank"><i class="fa-brands fa-tiktok"></i></a>
            </div>
        </div>
    </footer>
`