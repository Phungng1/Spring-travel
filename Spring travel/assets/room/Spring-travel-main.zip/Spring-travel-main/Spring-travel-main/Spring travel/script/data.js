const hotel = [
    {
        title : "The Jade Hotel",
        image : "jade.jpg",
        location: "Hanoi",
        address: "jade.html"
    },
    {
        title : "La Siesta Mamay ",
        image : "mamay.jpg",
        location: "Hanoi",
        address: "mamay.html"
    },
    {
        title : "La Siesta Resort",
        image : "resort.jpg",
        location: "Hoi An",
        address: "resort.html"
    },
    {
        title : "Allegro Luxury",
        image : "allegro.jpg",
        location: "Nha Trang",
        address: "allegro.html"
    },
    {
        title : "Premier Village",
        image : "premier.jpg",
        location: "Da Nang",
        address: "premier.html"
    },
    {
        title : "Solaria Hotel",
        image : "solaria.jpg",
        location: "Ho Chi Minh City",
        address: "solaria.html"
    },
    {
        title : "Anio Boutique",
        image : "anio.jpg",
        location: "Hue",
        address: "anio.html"
    },
    {
        title : "Grand Mercure",
        image : "mercure.jpg",
        location: "Hanoi",
        address: "mercure.html"
    },
    {
        title : "Hôtel de la Coupole",
        image : "coupole.jpg",
        location: "Phu Quoc",
        address: "coupole.html"
    },
    {
        title : "Fraser Suite",
        image : "fraser.jpg",
        location: "Sai Gon",
        address: "fraser.html"
    },
    {
        title : "The Jade Hotel",
        image : "jade.jpg",
        location: "Hanoi",
        address: "jade.html"
    },
    {
        title : "La Siesta Mamay ",
        image : "mamay.jpg",
        location: "Hanoi",
        address: "mamay.html"
    },
    {
        title : "La Siesta Resort",
        image : "resort.jpg",
        location: "Hoi An",
        address: "resort.html"
    },
    {
        title : "Allegro Luxury",
        image : "allegro.jpg",
        location: "Nha Trang",
        address: "allegro.html"
    },
    {
        title : "Premier Village",
        image : "premier.jpg",
        location: "Da Nang",
        address: "premier.html"
    },
    {
        title : "Solaria Hotel",
        image : "solaria.jpg",
        location: "Ho Chi Minh City",
        address: "solaria.html"
    },
    {
        title : "Anio Boutique",
        image : "anio.jpg",
        location: "Hue",
        address: "anio.html"
    },
    {
        title : "Grand Mercure",
        image : "mercure.jpg",
        location: "Hanoi",
        address: "mercure.html"
    },
    {
        title : "Hôtel de la Coupole",
        image : "coupole.jpg",
        location: "Phu Quoc",
        address: "coupole.html"
    },
    {
        title : "Fraser Suite",
        image : "fraser.jpg",
        location: "Sai Gon",
        address: "fraser.html"
    },

]



localStorage.setItem("hotel", JSON.stringify(hotel));